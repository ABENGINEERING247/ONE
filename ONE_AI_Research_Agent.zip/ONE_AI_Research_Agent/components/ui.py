import streamlit as st
from services.research import generate_research

def apply_theme():
    st.markdown("""
    <style>
    @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@400;500;600;700;800&display=swap');
    :root { --one-green:#138A72; --one-navy:#17332F; --one-mint:#E8F6F1; }
    html, body, [class*="css"] { font-family:'DM Sans',sans-serif; }
    .stApp { background:linear-gradient(180deg,#FFFFFF 0%,#FBFDFC 100%); color:var(--one-navy); }
    [data-testid="stSidebar"] { background:#F3F8F6; border-right:1px solid #DDEBE6; }
    h1,h2,h3 { font-family:'Manrope',sans-serif !important; letter-spacing:-.035em; color:var(--one-navy); }
    .hero { padding:2.1rem 1.5rem 1.8rem; text-align:center; border:1px solid #E0EEE8; border-radius:26px; background:radial-gradient(circle at 50% 0%,#E8F6F1 0%,#FFFFFF 64%); margin-bottom:1.2rem; }
    .hero h1 { font-size:clamp(2.3rem,5vw,4.2rem); line-height:1.05; margin:.4rem 0 1rem; }
    .hero h1 span { color:#138A72; }
    .hero p { color:#56716A; max-width:760px; margin:auto; font-size:1.05rem; }
    .eyebrow { color:#138A72; font-weight:700; font-size:.75rem; letter-spacing:.16em; }
    div.stButton > button[kind="primary"] { background:#138A72; border:1px solid #138A72; border-radius:12px; font-weight:700; min-height:3rem; }
    div.stButton > button { border-radius:11px; }
    [data-testid="stMetric"] { background:#FFFFFF; border:1px solid #E0EEE8; border-radius:14px; padding:1rem; }
    [data-testid="stVerticalBlockBorderWrapper"] { border-color:#E0EEE8 !important; border-radius:18px !important; }
    .footer { text-align:center; color:#698078; padding:2rem 0 1rem; font-size:.82rem; line-height:1.8; }
    .stTextArea textarea, .stTextInput input { border-radius:12px !important; }
    </style>
    """, unsafe_allow_html=True)

def render_header():
    a, b = st.columns([1, 5])
    with a:
        st.markdown("### <span style='color:#138A72'>◉ ONE</span>", unsafe_allow_html=True)
    with b:
        st.markdown("<div style='text-align:right;color:#678078;padding-top:.7rem;font-size:.88rem'>AUTONOMOUS AI RESEARCH AGENT</div>", unsafe_allow_html=True)

def render_sidebar():
    st.markdown("## ◉ ONE")
    st.caption("One Idea. A Complete Research Paper.")
    st.markdown("---")
    st.markdown("**Workspace**")
    st.markdown("✦  New research")
    st.markdown("▤  Manuscript editor")
    st.markdown("⌕  Sources & citations")
    st.markdown("⌘  LaTeX & exports")
    st.caption("Research drafts should be reviewed and verified before submission.")

def render_chatbot(project, mode):
    with st.popover("💬 Ask ONE", use_container_width=False):
        st.markdown("### Research assistant")
        st.caption("Ask about your current idea or manuscript.")
        if "one_chat" not in st.session_state:
            st.session_state["one_chat"] = []
        for item in st.session_state["one_chat"][-8:]:
            with st.chat_message(item["role"]):
                st.markdown(item["content"])
        question = st.text_input("Your question", key="one_chat_question", placeholder="Explain my research gap…")
        if st.button("Send", key="one_chat_send"):
            if question.strip():
                st.session_state["one_chat"].append({"role":"user","content":question.strip()})
                context = (project.get("paper","") or "")[:12000]
                if mode == "API Mode":
                    try:
                        answer, _ = generate_research(
                            "Answer this question about the current manuscript. Do not rewrite the entire paper. If the manuscript does not support an answer, say so.\n\nMANUSCRIPT:\n" + context + "\n\nQUESTION:\n" + question
                        )
                    except Exception as exc:
                        answer = f"Assistant unavailable: {exc}"
                else:
                    answer = "Demo Mode: I can help review the draft, but this reply is a sample. Switch to API Mode for model-generated assistance. Review the manuscript's evidence and references independently."
                st.session_state["one_chat"].append({"role":"assistant","content":answer[:5000]})
                st.rerun()
